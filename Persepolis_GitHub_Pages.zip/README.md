# Persepolis Escola Livre — GitHub Pages

Site estático institucional bilíngue, com estética afrofuturista, capa de oficina de recondicionamento, 20 fotografias da Persepolis, jornada do ciclo de equipamentos, soluções e contato por e-mail. Não exige Node, hospedagem paga nem banco de dados.

## Publicar no GitHub Pages (projeto novo)

1. Entre em https://github.com/new na conta que administrará o site (por exemplo, `persepolis-escola`).
2. Crie um repositório **público** com o nome `persepolis-institucional`; não adicione README ou `.gitignore` pelo formulário se você for enviar tudo pela linha de comando.
3. Extraia o ZIP e envie **todos os arquivos da pasta extraída diretamente para a raiz do repositório**, sem criar pasta intermediária. O arquivo `index.html` precisa ficar na raiz.
4. No GitHub, abra o repositório > **Settings** > **Pages**. Em **Build and deployment**, defina **Source: Deploy from a branch**. Escolha **Branch: main** e pasta **/(root)**, e clique **Save**.
5. Aguarde o processamento. O endereço esperado, se o repositório tiver esses nomes, será:
   https://persepolis-escola.github.io/persepolis-institucional/
   **A URL só passará a existir após a publicação do repositório**.

### Publicação via terminal (mais rápida para vários arquivos)

```bash
cd pasta-extraida
# O repositório precisa ter sido criado no GitHub antes
git init
git branch -M main
git add .
git commit -m "Site institucional afrofuturista da Persepolis"
git remote add origin https://github.com/persepolis-escola/persepolis-institucional.git
git push -u origin main
```

Ao executar o `git push`, o GitHub poderá solicitar autenticação (navegador, Git Credential Manager ou token). Não envie tokens nem senhas por mensagens.

### Atualizações futuras

Substitua os arquivos do repositório e faça novo commit na branch `main`. O Pages atualizará o site conforme a configuração acima.

## Domínio personalizado

O domínio `persepolisescola.com.br` **continua apontando para o site anterior até você alterar a configuração do DNS**. Faça um backup verificável do Wix e confira os registros existentes antes de iniciar a troca. Quando o site do GitHub Pages estiver testado, em **Settings > Pages > Custom domain** informe `persepolisescola.com.br` e siga os registros específicos indicados pelo GitHub para apex e `www`. Não modifique registros MX, SPF ou DKIM de e-mail. Nunca altere os servidores de nomes inteiros apenas para redirecionar o site. Ative HTTPS depois da validação de DNS.

## Conteúdo e limites

- `index.html` / `styles.css` / `app.js`: site completo, sem compilação.
- `assets/hero.webp`: capa de oficina de recondicionamento.
- `assets/fotos/`: 20 fotografias reais enviadas pela Persepolis e otimizadas em WebP.
- `assets/brand/`: símbolo vetorial.
- `.nojekyll`: evita o processamento Jekyll no GitHub Pages.
- O formulário cria uma mensagem no aplicativo de e-mail do visitante para `miro@persepolislab.com.br`; **não armazena nem envia dados automaticamente**.
- O simulador demonstra cenários hipotéticos, não resultados auditados ou compromisso de recuperação.
- Três documentos em PDF têm links externos para a publicação institucional original; para autonomia plena, copie os PDFs ao repositório e atualize esses endereços.
- O projeto foi reconstruído como site estático independente; não é um backup integral do código-fonte do Floot.
